import caffe
import scipy.misc
execfile('playBlocks.py')
import os
net = caffe.Net('dynConvPatch_deploy.prototxt', 'dynConvPatch_iter_300000')
net.set_phase_test()
net.set_mode_gpu()
net.set_input_scale(net.inputs[0], 1)
net.set_channel_swap(net.inputs[0], [0,1,2,3])
#net = caffe.Net('../../imagenet/imagenet_full_conv.prototxt', '../../imagenet/caffe_reference_imagenet_model')
import shutil
print net.params
import h5py

import numpy as np

#rndImg = np.zeros((64,64,4))

#inputs = [rndImg]

#import h5py
#f = h5py.File("Trn_1.h5","r")
#data = f['data'].value
#label = f['label'].value
#dataset = tst

#relIdx = range(numOfTestSamples)

relIdx = range(100)

framesPerSample = 4
imgH = 250
imgW = 250

totalLastScore = 0
totalPredScore = 0

resizeFlag = False

sampleCounter = 0

for iCnt,i in enumerate(relIdx):
    #print iCnt
    currentH5File = h5py.File("../../tstLL_" + str(i) + ".h5","r")
    numOfH5Samples = currentH5File["data"].value.shape[0]

    for d in range(numOfH5Samples):
	currentXMat = currentH5File["data"].value[d, :4, :, :].reshape(4, imgH, imgW)

            
	yImg = currentH5File["data"].value[d, 4, :, :].reshape(imgH, imgW)

    	inputForNN = numpy.zeros([625, 4, 70, 70])

    
    	for j in range(4):
		inputForNN[:, j, :, :] = genMatBlocks(currentXMat[j,:,:],XIdxBlocks,YIdxBlocks)

    	inputs=[inputForNN[a,:,:,:].reshape(4,70,70).transpose([1,2,0]) for a in range(inputForNN.shape[0])]
    	caffe_in = np.asarray([net.preprocess(net.inputs[0], in_) for in_ in inputs])
    	out = net.forward_all(**{net.inputs[0]: caffe_in})

    	finalMat=out['flattenCrop'].reshape(625,100)

    	finalMat = numpy.minimum(numpy.maximum(finalMat, 0), 1.0)
    
    	predImgMat = numpy.zeros([250,250])

	k = 0
	for l in range(25):
	    for r in range(25):
		  rowStart = l * 10
		  colStart = r * 10
		  predImgMat[rowStart:(rowStart+10),colStart:(colStart+10)] = finalMat[k,:].reshape([10,10])
		  k = k + 1
	    
    	curOutPath = r"./rndImgs/" + str(i) + "-" + str(d) + "/"
    	os.mkdir(curOutPath)
    	
	for a in range(4):
		scipy.misc.toimage(currentXMat[a, :, :].reshape(imgH, imgW), cmin=0, cmax=1.0).save(curOutPath + 'frame_' + str(a) + '.png')        
	
	
	currentXMat = currentXMat[:, 25:225, 25:225]
	yImg = yImg[25:225, 25:225]
	predImgMat = predImgMat[25:225, 25:225]
	#print currentXMat.shape
    	scipy.misc.toimage(predImgMat, cmin = 0, cmax = 1.0).save(curOutPath + 'predImg.png')
    	scipy.misc.toimage(yImg, cmin = 0, cmax = 1.0).save(curOutPath + 'realImg.png')
    	scipy.misc.toimage(currentXMat[3,:,:].reshape(200,200), cmin = 0, cmax = 1.0).save(curOutPath + 'lastImg.png')
    	predScore = numpy.power(predImgMat - yImg, 2).sum()
    	lastScore = numpy.power(currentXMat[3,:,:].reshape(200,200) - yImg, 2).sum()
    	totalLastScore = totalLastScore + lastScore
    	totalPredScore = totalPredScore + predScore
	
	sampleCounter = sampleCounter + 1
    	vecOut = [predScore, lastScore, (totalPredScore / (sampleCounter)), (totalLastScore / (sampleCounter))]
    	numpy.savetxt(curOutPath + "scores.txt", numpy.asarray(vecOut))
    	print vecOut

