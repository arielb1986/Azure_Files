import numpy as np
from numpy.lib.stride_tricks import as_strided as ast
A = np.asarray(range(250*250)).reshape([250,250])
import numpy

def block_view(A, block= (3, 3)):
    """Provide a 2D block view to 2D array. No error checking made.
    Therefore meaningful (as implemented) only for blocks strictly
    compatible with the shape of A."""
    # simple shape and strides computations may seem at first strange
    # unless one is able to recognize the 'tuple additions' involved ;-)
    shape= (A.shape[0]/ block[0], A.shape[1]/ block[1])+ block
    strides= (block[0]* A.strides[0], block[1]* A.strides[1])+ A.strides
    return ast(A, shape= shape, strides= strides)


B= block_view(A, block=(10,10))
YIdx, XIdx = np.meshgrid(range(250),range(250))
XIdxBlocks = block_view(XIdx, block=(10,10))
YIdxBlocks = block_view(YIdx, block=(10,10))


def genMatBlocks(mat, XIdxBlocksCenter, YIdxBlocksCenter, largeBlockRows=70, largeBlockCols=70):
    NBlocks = XIdxBlocksCenter.shape[0]
    MBlocks = XIdxBlocksCenter.shape[1]

    MCenterBlock = XIdxBlocksCenter.shape[2]
    NCenterBlock = XIdxBlocksCenter.shape[3]
    
    finalMat = numpy.zeros([NBlocks*MBlocks, largeBlockRows, largeBlockCols])

    rowsToPadFromEachSide = (largeBlockRows - MCenterBlock) /2
    colsToPadFromEachSide = (largeBlockCols - NCenterBlock) /2

    matRows = mat.shape[0]
    matCols = mat.shape[1]
    
    k = 0
    for i in range(NBlocks):
        for j in range(MBlocks):
            rowMinCenter = XIdxBlocksCenter[i,j].min() 
            rowMaxCenter = XIdxBlocksCenter[i,j].max()
            colMinCenter = YIdxBlocksCenter[i,j].min() 
            colMaxCenter = YIdxBlocksCenter[i,j].max()

            rowMinBlock = max(rowMinCenter - rowsToPadFromEachSide,0)
            rowMaxBlock = min(rowMaxCenter + rowsToPadFromEachSide,matRows - 1)
            colMinBlock = max(colMinCenter - colsToPadFromEachSide,0)
            colMaxBlock = min(colMaxCenter + colsToPadFromEachSide,matCols - 1)

            inBlockMinRow = rowsToPadFromEachSide - (rowMinCenter - rowMinBlock)
            inBlockMaxRow = (rowsToPadFromEachSide + MCenterBlock - 1)  + (rowMaxBlock - rowMaxCenter)
            inBlockMinCol = colsToPadFromEachSide - (colMinCenter - colMinBlock)
            inBlockMaxCol = (colsToPadFromEachSide + NCenterBlock - 1)  + (colMaxBlock - colMaxCenter)
        
            #print i,j
            #print inBlockMinRow,inBlockMaxRow,inBlockMinCol,inBlockMaxCol
            #print rowMinBlock,rowMaxBlock,colMinBlock,colMaxBlock
            #print "======"
            #print finalMat.shape
            currentMatBlock = mat[range(rowMinBlock, rowMaxBlock+1),:][:,range(colMinBlock, colMaxBlock+1)]
            #print currentMatBlock.shape
            #currentMatBlock = currentMatBlock.reshape([1,currentMatBlock.shape[0],currentMatBlock.shape[1]])
            #print finalMat[k,:,:][inBlockMinRow:(inBlockMaxRow+1),inBlockMinCol, inBlockMaxCol+1)].shape
            #print finalMat[k,range(inBlockMinRow, inBlockMaxRow+1),range(inBlockMinCol, inBlockMaxCol+1)].shape
            finalMat[k,inBlockMinRow:(inBlockMaxRow+1),inBlockMinCol:(inBlockMaxCol+1)] = currentMatBlock
            k=k+1

    return finalMat
