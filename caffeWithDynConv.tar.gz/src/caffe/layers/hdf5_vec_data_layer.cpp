// Copyright 2014 BVLC and contributors.
/*
TODO:
- load file in a separate thread ("prefetch")
- can be smarter about the memcpy call instead of doing it row-by-row
  :: use util functions caffe_copy, and Blob->offset()
  :: don't forget to update hdf5_daa_layer.cu accordingly
- add ability to shuffle filenames if flag is set
*/
#include <stdint.h>
#include <string>
#include <vector>
#include <fstream>  // NOLINT(readability/streams)

#include "hdf5.h"
#include "hdf5_hl.h"

#include "caffe/layer.hpp"
#include "caffe/util/io.hpp"
#include "caffe/vision_layers.hpp"

namespace caffe {

template <typename Dtype>
HDF5VecDataLayer<Dtype>::~HDF5VecDataLayer<Dtype>() { }

// Load data and label from HDF5 filename into the class property blobs.
template <typename Dtype>
void HDF5VecDataLayer<Dtype>::LoadHDF5FileData(const char* filename) {
  LOG(INFO) << "Loading HDF5 file" << filename;
  hid_t file_id = H5Fopen(filename, H5F_ACC_RDONLY, H5P_DEFAULT);
  if (file_id < 0) {
    LOG(ERROR) << "Failed opening HDF5 file" << filename;
    return;
  }

  const int MIN_DATA_DIM = 2;
  const int MAX_DATA_DIM = 4;
  hdf5_load_nd_dataset(
    file_id, "vec",  MIN_DATA_DIM, MAX_DATA_DIM, &vec_blob_);

  herr_t status = H5Fclose(file_id);
  CHECK_GE(status, 0) << "Failed to close HDF5 file " << filename;
}

template <typename Dtype>
void HDF5VecDataLayer<Dtype>::SetUp(const vector<Blob<Dtype>*>& bottom,
      vector<Blob<Dtype>*>* top) {
  Layer<Dtype>::SetUp(bottom, top);
  // Read the source to parse the filenames.
  const string& source = this->layer_param_.hdf5_vec_data_param().source();

  // Load the first HDF5 file and initialize the line counter.
  LoadHDF5FileData(source.c_str());

  // Reshape blobs.
  const int batch_size = this->layer_param_.hdf5_vec_data_param().batch_size();
  /*(*top)[0]->Reshape(batch_size, data_blob_.channels(),
                     data_blob_.width(), data_blob_.height());
  (*top)[1]->Reshape(batch_size, label_blob_.channels(),
                     label_blob_.width(), label_blob_.height());*/
  (*top)[0]->Reshape(batch_size, vec_blob_.channels(),
                     vec_blob_.height(), vec_blob_.width());

  LOG(INFO) << "output data size: " << (*top)[0]->num() << ","
      << (*top)[0]->channels() << "," << (*top)[0]->height() << ","
      << (*top)[0]->width();
}

template <typename Dtype>
Dtype HDF5VecDataLayer<Dtype>::Forward_cpu(const vector<Blob<Dtype>*>& bottom,
      vector<Blob<Dtype>*>* top) {
  const int batch_size = this->layer_param_.hdf5_vec_data_param().batch_size();
  const int data_count = (*top)[0]->count() / (*top)[0]->num();
  //LOG(INFO) << "H1" << " " << data_count << " " << vec_blob_.cpu_data()[0];
  for (int i = 0; i < batch_size; ++i) {
    //LOG(INFO) << "H3";
    memcpy(&(*top)[0]->mutable_cpu_data()[i * data_count],
           &vec_blob_.cpu_data()[0],
           sizeof(Dtype) * data_count);
  }
  //LOG(INFO) << "H2" << " " << (*top)[0]->cpu_data()[0];
  return Dtype(0.);
}

#ifdef CPU_ONLY
STUB_GPU_FORWARD(HDF5VecDataLayer, Forward);
#endif

INSTANTIATE_CLASS(HDF5VecDataLayer);

}  // namespace caffe
