// Copyright 2014 BVLC and contributors.

#include <vector>

#include <omp.h>

#include "caffe/layer.hpp"
#include "caffe/vision_layers.hpp"
#include "caffe/util/im2col.hpp"
#include "caffe/filler.hpp"
#include "caffe/util/math_functions.hpp"

namespace caffe {

template <typename Dtype>
void CropLayer<Dtype>::SetUp(const vector<Blob<Dtype>*>& bottom,
      vector<Blob<Dtype>*>* top) {
  Layer<Dtype>::SetUp(bottom, top);

  CHECK_EQ(bottom.size(), 1) << "Crop Layer takes one blob as input.";
  CHECK_EQ(top->size(), 1) << "Crop Layer takes one blob as output.";

  CropParameter crop_param = this->layer_param_.crop_param();
  h_begin_ = crop_param.h_begin();
  h_end_ = crop_param.h_end();
  w_begin_ = crop_param.w_begin();
  w_end_ = crop_param.w_end();

  num_ = bottom[0]->num();
  channels_ = bottom[0]->channels();
  height_ = bottom[0]->height();
  width_ = bottom[0]->width();
  
  CHECK_GE(h_begin_, 0) << "Height begin is non negative";
  CHECK_GE(w_begin_, 0) << "Width begin is non negative.";
  CHECK_LT(h_end_, height_) << "Height end is bounded by original height.";
  CHECK_LT(w_end_, width_) << "Width end is bounded by original width.";

  height_out_ = (h_end_ - h_begin_ + 1);
  width_out_ = (w_end_ - w_begin_ + 1);

  (*top)[0]->Reshape(num_, channels_, height_out_, width_out_);
}


template <typename Dtype>
Dtype CropLayer<Dtype>::Forward_cpu(const vector<Blob<Dtype>*>& bottom,
      vector<Blob<Dtype>*>* top) {
  
  const Dtype* bottom_data = bottom[0]->cpu_data();
  Dtype* top_data = (*top)[0]->mutable_cpu_data();

  caffe_set((*top)[0]->count(), Dtype(0), top_data);
  int k = 0;

  #pragma omp parallel for
  for (int n = 0; n < num_; ++n) {
	Dtype* current_top_data = top_data + (*top)[0]->offset(n);
	const Dtype* current_bottom_data = bottom_data + bottom[0]->offset(n);
		
  	for (int c = 0; c < channels_; ++c) {
		for (int h = 0; h < height_; ++h) {
			for (int w = 0; w < width_; ++w) {
				int h_out_idx = h - h_begin_;
				int w_out_idx = w - w_begin_;

				if ((h_out_idx >= 0) && (h_out_idx < height_out_) && (w_out_idx >= 0) && (w_out_idx < width_out_)) 
				{
					current_top_data[0] = current_bottom_data[0];
					current_top_data++;
				}
				//LOG(INFO) << "H1 " << k;
				//k++;
				
				current_bottom_data++;
			}
		}

	}
  }      
  return Dtype(0.);
}

template <typename Dtype>
void CropLayer<Dtype>::Backward_cpu(const vector<Blob<Dtype>*>& top,
      const vector<bool>& propagate_down, vector<Blob<Dtype>*>* bottom) {
 
  Dtype* bottom_diff = (*bottom)[0]->mutable_cpu_diff();
  const Dtype* top_diff = top[0]->cpu_diff();
  caffe_set((*bottom)[0]->count(), Dtype(0), bottom_diff);

  #pragma omp parallel for
  for (int n = 0; n < num_; ++n) {
	const Dtype* current_top_diff = top_diff + top[0]->offset(n);
	Dtype* current_bottom_diff = bottom_diff + (*bottom)[0]->offset(n);
	
	for (int c = 0; c < channels_; ++c) {
		for (int h = 0; h < height_; ++h) {
			for (int w = 0; w < width_; ++w) {
				int h_out_idx = h - h_begin_;
				int w_out_idx = w - w_begin_;

				if ((h_out_idx >= 0) && (h_out_idx < height_out_) && (w_out_idx >= 0) && (w_out_idx < width_out_)) 
				{
					current_bottom_diff[0] = current_top_diff[0];
					current_top_diff++;
				}
			
				
				current_bottom_diff++;
			}
		}

	}
  }
}

#ifdef CPU_ONLY
STUB_GPU(CropLayer);
#endif

INSTANTIATE_CLASS(CropLayer);

}  // namespace caffe
