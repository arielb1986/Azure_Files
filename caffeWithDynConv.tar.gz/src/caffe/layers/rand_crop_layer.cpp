// Copyright 2014 BVLC and contributors.

#include <vector>

#include "caffe/layer.hpp"
#include "caffe/vision_layers.hpp"
#include "caffe/util/im2col.hpp"
#include "caffe/filler.hpp"
#include "caffe/util/math_functions.hpp"

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

namespace caffe {

template <typename Dtype>
void RandCropLayer<Dtype>::SetUp(const vector<Blob<Dtype>*>& bottom,
      vector<Blob<Dtype>*>* top) {
  Layer<Dtype>::SetUp(bottom, top);

  CHECK_EQ(bottom.size(), 1) << "Crop Layer takes one blob as input.";
  CHECK_EQ(top->size(), 1) << "Crop Layer takes one blob as output.";

  RandCropParameter crop_param = this->layer_param_.rand_crop_param();
  h_size_ = crop_param.h_size();
  w_size_ = crop_param.w_size();
  num_out_ = crop_param.num_out();

  h_start_min_ = crop_param.h_start_min();
  w_start_min_ = crop_param.w_start_min();
  h_start_max_ = crop_param.h_start_max();
  w_start_max_ = crop_param.w_start_max();


  num_ = bottom[0]->num();
  channels_ = bottom[0]->channels();
  height_ = bottom[0]->height();
  width_ = bottom[0]->width();
  
  //CHECK_EQ(num_, 1) << "Num must be one.";
  CHECK_GE(h_size_, 0) << "Height begin is non negative";
  CHECK_GE(w_size_, 0) << "Width begin is non negative.";
  CHECK_LT(h_size_, height_) << "Height end is bounded by original height.";
  CHECK_LT(w_size_, width_) << "Width end is bounded by original width.";

  height_out_ = h_size_;
  width_out_ = w_size_;

  (*top)[0]->Reshape(num_, channels_, height_out_, width_out_);
  srand (time(NULL));
}


template <typename Dtype>
Dtype RandCropLayer<Dtype>::Forward_cpu(const vector<Blob<Dtype>*>& bottom,
      vector<Blob<Dtype>*>* top) {
  
  const Dtype* bottom_data = bottom[0]->cpu_data();
  Dtype* top_data = (*top)[0]->mutable_cpu_data();

  caffe_set((*top)[0]->count(), Dtype(0), top_data);
  int k = 0;
  for (int n = 0; n < num_; ++n) {
	
		const Dtype* current_bottom_data = bottom_data + bottom[0]->offset(n);
		Dtype* current_top_data = top_data + (*top)[0]->offset(n);
		int h_begin = h_start_min_ + rand() % (h_start_max_ - h_start_min_ + 1);
		int w_begin = w_start_min_ + rand() % (w_start_max_ - w_start_min_ + 1);
		
		//LOG(INFO) << h_begin << " " << w_begin << " " << n;
	  	
		for (int c = 0; c < channels_; ++c) {
			for (int h = 0; h < height_; ++h) {
				for (int w = 0; w < width_; ++w) {
					int h_out_idx = h - h_begin;
					int w_out_idx = w - w_begin;

					
					if ((h_out_idx >= 0) && (h_out_idx < height_out_) && (w_out_idx >= 0) && (w_out_idx < width_out_)) 
					{
						current_top_data[0] = current_bottom_data[0];

						current_top_data++;
					}
					
					current_bottom_data++;
				}
			}

		}
	
  }      
  return Dtype(0.);
}


#ifdef CPU_ONLY
STUB_GPU_FORWARD(RandCropLayer, Forward);
#endif

INSTANTIATE_CLASS(RandCropLayer);

}  // namespace caffe
